MOST+

Quick start:
------------
1) To install 
tar xzvf MOST+_v*.tar.gz 
where * stands the version. 
cd ./MOST+_v*/src
make

2) To run the example: 
cd ../test/
./testMost.sh 

3) To run stand alone version
cd ../
./most

Please check README and help information in MOST+ (./most -h) for more details


Prerequites:
------------
1) g++ version 4.0 or higher

2) python version 2.5 or higher

Contact:
--------
Jeremy071242044@gmail.com
