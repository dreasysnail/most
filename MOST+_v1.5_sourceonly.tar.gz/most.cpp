
//
//  most.cpp
//  MOST
//
//  Created by icarus on 12-5-10.
//  Copyright 2012年 sjtu. All rights reserved.
//

#include <iostream>
#include <string>
#include <queue>
#include <algorithm>
#include <cctype>
#include <sys/stat.h>
#include <sys/types.h>
#include "common.h"
#include "bwt.h"
#include "motif.h"
#include "FFT.h"
#include "Clustering.h"
#include <cstdlib>

using namespace std;

//global var's declarision

extern string T;
extern int N;

extern int RegionSize;
extern Edge* Edges;
extern Node* Nodes;
extern map<string,string> option;

void test();
int temp;

int main(int argc, char **argv)
{

    
    clock_t tStart,t1,t2,t2_1,t3,t4,tEnd;
    tStart=clock();
    
    /********************* parse files ***********************/

    parseCommandLine(argc, argv);
    genomeRegions *gR = new genomeRegions(atoi(option["flanking"].c_str()));
    


    cerr<<"START MOTIF FINDING"<<endl;
    
    while (true) {
        
        string outPutDir(option["outdir"]); 
        system(("rm -rf "+outPutDir).c_str());
        
        if (mkdir(outPutDir.c_str(),S_IRWXU|S_IRWXG|S_IRWXO)!= 0)
            printAndExit("cannot make directory");
        
        //parsing fasta and region
        if (option["regionfastafile"]=="") {
            gR->readFasta(option["fastafile"]);
            gR->readBed(option["regionfile"]);
            gR->mergeOverlap();
            // rm control peaks
            if (option["control"]!="") {
                cerr<<"control File（bedFormat）:"<<option["control"]<<endl;
                gR->rmControlPeaks(option["control"]);
            }
            gR->getSeq(outPutDir);
            if (option["mode"]=="extract")
                exit(0);
        }
        else {
            gR->readRegionFasta(option["regionfastafile"]);
        }
        
        //region-wide
        switch (option["bkgregion"][0]) {
            case 'r':
            case 'R':
                gR->initProb(2);
                break;
            default:
                gR->initProb(1);
                break;
        } 
        
        //initiate whole sequence 
        cerr<<"regionFile（bedFormat）:"<<option["regionfile"]<<endl;
        RegionSize = gR->appendReverseGenome(T);
        t1=clock();
        cerr<<"Parsing Fasta:"<<double((t1-tStart)/1e6)<<endl;

    
        // tag mode
        if (option["mode"]=="tag") {

            string fileName("");
            string tagFileNames(option["tagfile"]);
            istringstream ss(tagFileNames);
            while (ss>>fileName) {
                cerr<<"tagfile:"<<fileName<<endl;
                gR->readWig(fileName);
            }
            gR->catenateTags();
            t2_1=clock();
            cerr<<"Parsing Wig:"<<double((t2_1-t1)/1e6)<<endl;
            t1=t2_1;
            
            for (int i=0; i<gR->tagName.size(); i++) {
                cerr<<gR->tagName[i]<<" size:"<<gR->regionTags[gR->tagName[i]].size()<<"\t";
                cerr<<long(gR->regionTags[gR->tagName[i]].size())-EXTEND_BOUND*4*gR->segmentCount<<endl;
                assert(RegionSize==long(gR->regionTags[gR->tagName[i]].size())-EXTEND_BOUND*4*gR->segmentCount);
            }
        }
        cerr<<"RegionSize:"<<RegionSize<<endl;
        assert(gR->segmentStartPos.back()==RegionSize);
        
        
        /********************* Count occurence ***********************/
        
        
        Edges = new Edge[long(RegionSize*2*HASH_TABLE_MULTIPLER)];
        Nodes = new Node[RegionSize*2+1];
        HASH_TABLE_SIZE =long(RegionSize*2*HASH_TABLE_MULTIPLER);
        
        N = T.size() - 1;
        
        Suffix active( 0, 0, -1 );  // The initial active prefix
        for ( int i = 0 ; i <= N ; i++ )
            active.AddPrefix(i);
        t2=clock();
    
        cerr<<"built suffix tree:"<<double((t2-t2)/1e6)<<endl;
            
        //count words
        string fileName = outPutDir + "/cluster.log";
        ofstream clusterFile(fileName.c_str(),ios::app);
        
        //pop minimal element from heap 
        priority_queue<Motif,vector<Motif>,compareMotif> wordHeap;
        
        const int K_4=int(pow1(4, K));
        int counter1 = 0;
        bool rmrepeat = (option["rmrepeat"]!="0");
        for (int i = 0; i <(K_4); i++) {
            printProgress(i,K_4,"Qualify kmer from suffix tree:");
            Motif thisMotif(i);
            //if (!thisMotif.noWildcard()) continue;
            //order null
            thisMotif.initProb((*gR),atoi(option["order"].c_str()));
            thisMotif.loci = active.locateMotif(thisMotif);
            //cerr<<thisMotif.loci.size()<<endl;
            temp += thisMotif.loci.size();
            thisMotif.calConscore(RegionSize);
            if (thisMotif.score) {
                if (rmrepeat&&thisMotif.isRepeat()) {
                    continue;
                }
                counter1++;
                thisMotif.initPFM();
                //thisMotif.initLociScore();
                if (option["mode"]=="tag"){
                    thisMotif.testMotifTag(*gR, false);
                }
                thisMotif.sumOverallScore();
                if (counter1==1) {
                    wordHeap.push(thisMotif);
                }
                // ranking according to overallScore
                if (wordHeap.size()<MAX_WORD_NUM||thisMotif.overallScore>wordHeap.top().overallScore) {
                   //protocol:has pfm loci lociscore sign noise conscore motifProb overallscore  bins  sumbin.
                    wordHeap.push(thisMotif);
                    if (wordHeap.size()>MAX_WORD_NUM) {
                        wordHeap.pop();
                    }
                }
            }
        }
        cerr<<"clustering result:";
        cerr<<"\n"<<"STAGE1(filter words with low frequence):"<<K_4-counter1<<" kmer was filtered"<<"\n";
        if (option["mode"]=="tag"){
            cerr<<"STAGE2:"<<counter1-wordHeap.size()<<" kmer was filtered"<<"\n";
        }
        cerr<<"Left:"<<wordHeap.size()<<endl;
        cerr<<"total motifs'loci size:"<<temp<<" approximate "<<RegionSize<<endl;
        //need to eliminate allmotif
        if (wordHeap.size()==0) {
            printAndExit("too strict parameters!");
        }
        t3=clock();
        
        cerr<<"count words:"<<double((t3-t2)/1e6)<<endl;
        

        /********************* Clustering ***********************/
        
        
        int maxWordCnt=min(MAX_WORD_NUM, int(wordHeap.size()));
        vector<Cluster> qualifiedMotifs;
        qualifiedMotifs.reserve(MAX_WORD_NUM);
        
        //extend motif
        if (option["extendmotif"]=="T") {
            while (!wordHeap.empty())
            {
                Cluster temp0(Motif (1));
                temp0.getExtended(wordHeap.top(), *gR, active);
                qualifiedMotifs.push_back(temp0);
                wordHeap.pop();
            }
        }
        else {
            while (!wordHeap.empty())
            {
                Cluster temp0(wordHeap.top());
                qualifiedMotifs.push_back(temp0);
                wordHeap.pop();
            }
        }
        
        //?? clear memory
        delete [] Nodes;
        delete [] Edges;
        
        //qualifiedMotifs[0].printMotif();
        sort(qualifiedMotifs.begin(),qualifiedMotifs.end(),compareMotif());
        
        //Output qualified words into file
#ifdef QUALIFIED
        ofstream wordFile((option["outdir"]+"/qualified.log").c_str());
        ofstream wordDist((option["outdir"]+"/qualified.dist").c_str());
        for (int i=0; i<qualifiedMotifs.size(); i++) {
            qualifiedMotifs[i].printMotif(wordFile);
        }
        for (int i=0; i<qualifiedMotifs.size(); i++) {
            if (qualifiedMotifs[i].implicit()) {
                continue;
            }
            qualifiedMotifs[i].drawDist(*gR, wordDist);
        } 
#endif
        
        //write pfm file;
#ifdef QUALIFIEDPFM
        ofstream pfmWordFile((option["outdir"]+"/qualified.pfm").c_str());
        if (!pfmWordFile) {
            printAndExit("Error! Fail to open pfmFile for writing!");
        }
        for (int i = 0; i<qualifiedMotifs.size(); i++) {
            printProgress(i,qualifiedMotifs.size(), "Generate PFM file for qualified words");
            pfmWordFile<<qualifiedMotifs[i];
        }
#endif
        
        //Write chip-seq peak's tag distribution(centered at center of each fragment)
#ifdef CHIPEDPEAKDIST
        //output dist centered by chiped peaks
        ofstream CHIPDist((option["outdir"]+"/ChIPed_Peaks.dist").c_str());
        Motif chipPeaks(1);
        chipPeaks.loci.clear();
        for (int i=0; i<gR->segmentStartPos.size()-2 ;i++) {
            chipPeaks.loci.push_back((gR->segmentStartPos[i]+gR->segmentStartPos[i+1])/2);
        }
        /* ??  
        for (int j=0; j<clusters.size(); j++){
            fileName = outPutDir + "/chippeaks.bed";
            ofstream lociFile(fileName.c_str(),ios::app);
            chipPeaks.writeLoci(lociFile, *gR);
        }
        */
        chipPeaks.testMotifTag(*gR, false);
        chipPeaks.drawDist(*gR, CHIPDist);
#endif
        //qualifiedMotifs[0].printMotif();

        
        //New Routine for clustering
        int exceedLengthCount = 0;
        int normalAligned = 0;
        int totalCnt = 0;
        
        matrix_t distMat;
        InitMatrix(distMat, qualifiedMotifs.size(), qualifiedMotifs.size(), 0);
        float tagDistWgt = atoi(option["TdistWgt"].c_str());
    
        for (int i=0; i<qualifiedMotifs.size(); i++) {
            for (int j=i+1; j<qualifiedMotifs.size(); j++) {
                try {
                    float tagDist = 0;
                    pair<float,int> dist_shift = qualifiedMotifs[j].motifDistance(qualifiedMotifs[i]);
                    if (option["mode"]=="tag"){
                        tagDist = qualifiedMotifs[i].tagDistrDistance(qualifiedMotifs[j]);
                    }
                    distMat[i][j] = dist_shift.first + tagDistWgt*tagDist;
                    distMat[j][i] = distMat[i][j];
                }
                catch (exception &e) {
                    cerr<<e.what()<<endl;
                }
            }
        }
        
        matrix_t fabsDistMat = FabsMatrix(distMat);
        vector<TreeNode> tn;
        //tn = SingleLinkClstr(fabsDistMat);
        tn = CompleteLinkClstr(fabsDistMat);
        int bestClstrNum = GapStatistics(fabsDistMat, tn, 2);
        vector<int> clusterId;
        clusterId = cutTree(tn, bestClstrNum);

#ifdef DISTMAT_AND_INDEX
        ofstream fabsDistMatFile((option["outdir"]+"/clusterDist.tsv").c_str());
        fabsDistMatFile<<fabsDistMat<<endl;
        ofstream ClstrIdxFile((option["outdir"]+"/clusterIdx.tsv").c_str());
        ClstrIdxFile<<clusterId<<endl;
        //cerr<<clusterId<<endl;
        //cerr<<MAX_DIST<<endl;
#endif
        
        vector<Cluster> clusters;
        

        //choose the first element in each cluster as representative
        for (int clstrIdx=0; clstrIdx<bestClstrNum; clstrIdx++) {
            vector<int> sliceIdx;
            for (int i=0; i<clusterId.size(); i++) {
                if (clusterId[i]==clstrIdx) {
                    sliceIdx.push_back(i);
                }
            }
            int rep=GetRepElement(fabsDistMat, clusterId, clstrIdx);
            if (rep==-1) printAndExit("cannot find representative elemnent");
            clusters.push_back(qualifiedMotifs[sliceIdx[rep]]);
            for (int i=0; i<sliceIdx.size(); i++) {
                if (i==rep) {
                    continue;
                }
                pair<float,int> dist_shift = clusters.back().motifDistance(qualifiedMotifs[sliceIdx[i]]);
                int thisShift = static_cast<int>(dist_shift.second);
                float thisDist = dist_shift.first;
                //discard antisense
                bool aligned = (thisDist>0&&thisDist<=MAX_DIST);
                int queryLength = clusters.back().pfm[0].size();
                //if cluster size exceed Max cluster size after this motif appended,discard
                bool exceedLength = (queryLength>=atoi(option["clusterlength"].c_str()));
                if (aligned&&!exceedLength) {
                    //add member
                    Member tempM={thisShift,
                        qualifiedMotifs[sliceIdx[i]].tagBiPeak,
                        qualifiedMotifs[sliceIdx[i]].tagSymmetry,
                        thisDist,
                        qualifiedMotifs[sliceIdx[i]].query};
                    clusters.back().Members.push_back(tempM);
                    
                    //recalculate attributes
                    clusters.back().calPFM(qualifiedMotifs[sliceIdx[i]], thisShift);
                    if (option["mode"]=="tag"){
                        clusters.back().reCalSumBin(qualifiedMotifs[sliceIdx[i]], *gR);
                    }
                    clusters.back().appendLoci(qualifiedMotifs[sliceIdx[i]]);
                    //merge score and prob
                    clusters.back().mergeProb(qualifiedMotifs[sliceIdx[i]]);
                    //update noise and tagscore
                    clusters.back().testMotifTag(*gR,false);
                    //using representative member's score
                    //clusters.back().sumOverallScore();
                    
                }
                //counting and feedbacking
                if (aligned) normalAligned++;
                if (exceedLength) exceedLengthCount++;
                printProgress(totalCnt,qualifiedMotifs.size(), "Clustering");
                totalCnt++;
                          
            }
        }
        
        //final processing
        for (int j=0; j<clusters.size(); j++){
            // already sorted clusters
            clusters[j].generateIUPAC();
            clusters[j].trim();
            clusters[j].mergeLoci();
            clusters[j].testMotifTag(*gR,option["drawdist"]=="T");
            //clusters[j].calConscore(RegionSize);
            //clusters[j].sumOverallScore();
        }
        
        sort(clusters.begin(),clusters.end(),compareMotif());
        //write cluster file
#ifdef CLUSTERLOG
        clusterFile<<"\n";
        for (int j=0; j<clusters.size(); j++){
            clusterFile<<setw(8)<<"CLUSTER\t"<<setw(3)<<j<<"\t";
            clusters[j].printMember(clusterFile);
            clusterFile<<flush;
            clusterFile<<endl;
        }
#endif
        

        t4=clock();
        cerr<<"\nclustering:"<<double((t4-t3)/1e6)<<endl;
        cerr<<"Total:"<<qualifiedMotifs.size()<<"\tExceed Length:"<<exceedLengthCount<<"\tAligned:"<<normalAligned<<"\tClusters:"<<clusters.size()<<endl;
        
        
        
    /********************* write files ***********************/
        if (option["writeloci"]=="T") {
            clock_t t5=clock();
            for (int j=0; j<clusters.size(); j++){
                fileName = outPutDir + "/clustersLoci.bed";
                ofstream lociFile(fileName.c_str(),ios::app);
                clusters[j].writeLoci(lociFile, *gR);
            }
            cerr<<"writeLoci:"<<double((t5-t4)/1e6)<<endl;
            t4=t5;
        }
        
        
        
        //write score info to cout
        cout<<setw(20)<<setiosflags(std::ios::left)<<"Motif"<<"\tP-value\tConscore\t";
        for (int i=0; i<gR->tagName.size(); i++) {
            cout<<gR->tagName[i]<<"_Bipeaks\t";
            
        }
        for (int i=0; i<gR->tagName.size(); i++) {
            cout<<gR->tagName[i]<<"_assymmetry\t";
            
        }
        for (int i=0; i<gR->tagName.size(); i++) {
            cout<<gR->tagName[i]<<"_intensity\t";
            
        }
        if (option["FFT"]=="T") {
            for (int i=0; i<gR->tagName.size(); i++) {
                cout<<gR->tagName[i]<<"_tagNoise\t";
                
            }
        }
        cout<<"lociSize:"<<endl;
        for (int i=0; i<clusters.size(); i++){
            clusters[i].printMotif(cout);
        }
        
        //write pfm file;
        fileName = outPutDir + "/allmotif.pfm";
        ofstream pfmFile(fileName.c_str());
        if (!pfmFile) {
            printAndExit("Error! Fail to open pfmFile for writing!");
        }
        for (int i = 0; i<clusters.size(); i++) {
            printProgress(i,clusters.size(), "Generate PFM file");
            pfmFile<<clusters[i];
            
            
        }            
        //write pfm and dist
        
        tEnd=clock();
        cerr<<"total time eclapse:"<<double((tEnd-tStart)/1e6)<<endl;
        
        exit(0);
    }
    return 0;
}






